const http = require('http'); 

const server = http.createServer((req, res) => { 
    
    // 1. Xử lý trang chủ (Home Page) - Cần hiển thị tên bạn
    if (req.url === '/') { 
        res.writeHead(200, { 'Content-Type': 'text/html' }); 
        // Đã thêm tên Khoa vào thẻ h1
        res.write('<html><body><h1>This is home Page. Khoa</h1></body></html>'); 
        res.end(); 
    }
    // 2. Xử lý trang Student
    else if (req.url === '/student') { 
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.write('<html><body><h1>This is student Page.</h1></body></html>');
        res.end();
    }
    // 3. Xử lý trang Admin
    else if (req.url === '/admin') {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.write('<html><body><h1>This is admin Page.</h1></body></html>');
        res.end();
    }
    // 4. Xử lý trang Data (trả về JSON)
    else if (req.url === '/data') { 
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.write(JSON.stringify({ message: "Hello World JSON" })); 
        res.end();
    }
    // 5. Xử lý các đường dẫn không hợp lệ (Invalid Request)
    else {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.write('Invalid Request!');
        res.end();
    }
});

server.listen(8080); 
// Đã thêm tên Khoa vào log khi chạy server
console.log('Node.js web server at port 8080 is running... Khoa');
